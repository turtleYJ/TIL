<?php

/* TEMPLATE PLUGIN FUNCTION EXAMPLE */

function returnHello($user='world')
{
	return 'hello '.$user;
}
?>